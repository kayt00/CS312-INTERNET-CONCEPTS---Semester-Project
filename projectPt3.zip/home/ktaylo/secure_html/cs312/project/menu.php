<?php

	//Katie Taylor - March 13, 2020             
        include 'header.php';
	
?>
	<body>
		<div id="container">  	
			<div id="sidebar">
			    <ul>
    				<li><a href="index.php">Home</a></li>
    				<li><a href="about.php">About Us</a></li>
    				<li><a href="events.php">Events</a></li>
    				<li><a href="adoption.php">Adoption</a></li>
    				<li><a href="volunteer.php">Volunteer</a></li>
			    </ul>
			</div>
		</div>
	</body>
