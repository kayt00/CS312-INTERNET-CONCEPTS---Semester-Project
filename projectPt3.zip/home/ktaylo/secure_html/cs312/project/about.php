<?php 
	//Katie Taylor - February 13, 2020
	include 'header.php';
?>
	<body>
                <div id="container">
                        <div id="header">
                                <h1>Ultimutt Animal Rescue</h1>
			</div>
			
			<div id="column0"><?php include 'menu.php' ?></div>
			
			<div id="column1"><h2>Mission</h2><br>
				<div id="about">To create a more humane and responsible community by eliminating animal suffering while increasing human compassion.</div>
                       
				<h2>Our Impact</h2>
                			<ul>
					   <li>Dogs - 1,308</li>
					   <li>Cats - 496</li>
					   <li>Other - 56</li>
		         		</ul>
			</div>

			<div id="column2"><h3>Location</h3><br>
                		
				<div id="about">3040 Holland Road<br>
						Virginia Beach, VA 23453</div>
		
				<h3>Hours</h3><br> 
                			<div id="about">Monday: 9:00am – 5:00pm<br>
							Tuesday: 9:00am – 5:00pm<br>
							Wednesday: 9:00am – 6:00pm<br>
							Thursday: 9:00am – 5:00pm<br>
							Friday: 9:00am – 5:00pm<br>
							Saturday: 9:00am – 3:00pm<br>
							Sunday: 12:00am - 3:00pm<br></div>

				<h3>Contact Us</h3><br>
                			<div id="about">Phone: (757)312-2020<br>
							Email: ultimuttanimalrescue@gmail.com<br></div>
				<br><br>
			</div>
                           
		 <div id="footer">Ultimutt Animal Rescue is a 501(c)(3) non-profit organization.
                         Copyright © 2020 · All Rights Reserved · Ultimutt Animal Rescue.</div>
		</div>
	</body>


