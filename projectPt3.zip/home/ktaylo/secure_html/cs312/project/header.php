<?php 
	//Katie Taylor - February 15, 2020
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
        	<title>CS312 Term Project</title>
        	<link href="std.css" rel="stylesheet" type="text/css">
        	<meta charset="UTF-8"/>
	</head>
</html>
